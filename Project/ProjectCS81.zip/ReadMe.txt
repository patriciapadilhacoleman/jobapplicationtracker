Job Application Tracker

The goal of this simple Web app is to help a job seeker keep track of where he/she has applied and follow up easier. In this first phase, I have implemented a simple user-interface utilizing bootstrap. 
In this version I added the JavaScript and JQuery functionality to display the new job applications and interviews on screen.
In a different version uploaded to the CS85 website, I implemented the database functionality using PHP and mySQL.
if you have any questions or suggestions, please contact me at patricia.p.coleman@gmail.com.

